class ClienteEspecial extends Cliente {

    private dependentes: Array<Cliente>;

    constructor(nome: string, cpf: string, conta: Conta) {
        super(nome,cpf,conta);
    }

    inserirDependente(Cliente: Cliente): void {
        this.dependentes.push(Cliente);
    }

    listarDependentes(): Array<Cliente> {
        return this.dependentes;
    }
}
