class ClienteEspecial extends Cliente {
    constructor(nome, cpf, conta) {
        super(nome, cpf, conta);
    }
    inserirDependente(Cliente) {
        this.dependentes.push(Cliente);
    }
    listarDependentes() {
        return this.dependentes;
    }
}
