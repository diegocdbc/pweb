class Clientes {
    constructor() {
        this.clientes = new Array();
        const c1 = new Cliente('Cleiton', '78945612355', new Conta('123456', 5000));
        const c2 = new Cliente('Ojuara', '65432198766', new Conta('789456', 150));
        this.clientes.push(c1, c2);
    }
    inserir(Cliente) {
        this.clientes.push(Cliente);
    }
    remover(cpf) {
        const ClienteARemover = this.pesquisar(cpf);
        if (ClienteARemover) {
            const indiceCliente = this.clientes.indexOf(ClienteARemover);
            if (indiceCliente > -1) {
                this.clientes.splice(indiceCliente, 1);
            }
        }
    }
    pesquisar(cpf) {
        return this.clientes.find(Cliente => Cliente.cpf === cpf);
    }
    listar() {
        return this.clientes;
    }
}
