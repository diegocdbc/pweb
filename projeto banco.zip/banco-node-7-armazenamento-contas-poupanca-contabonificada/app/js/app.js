let contaController = new ContaController();
let clienteController = new ClienteController();
contaController.listar();
clienteController.listar();
/*let c1 = new Conta('1', 100);
const p1 = new Poupanca('2', 100);*/
const cb1 = new ContaBonificada('3', 0);
/*console.log('Conta: ' + c1.saldo);

p1.atualizarSaldoAniversario();
console.log('Poupanca: ' + p1.saldo);*/
cb1.creditar(200);
console.log('Conta Bonificada: ' + cb1.saldo);
const cl1 = new Cliente('Halercio', '97812345688', new Conta('123456', 5000));
const cl2 = new Cliente('Creuza', '369258147421', new Conta('789456', 150));
console.log("Cliente: " + cl1.nome);
console.log("Cliente: " + cl2.nome);
const cs1 = new Clientes();
cs1.inserir(cl1);
cs1.inserir(cl2);
cs1.listar;
console.log("Lista de clientes: " + cs1.listar);
cs1.remover('97812345688');
cs1.pesquisar('97812345688');
cs1.pesquisar('369258147421');
